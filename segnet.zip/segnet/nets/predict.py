# -*- coding: utf-8 -*-
"""
Created on Sun Jun  7 17:14:38 2020

@author: Administrator
"""

from nets.segnet import convnet_segnet
from PIL import Image
import numpy as np
import copy
import os
import cv2

from time import clock


os.environ['CUDA_VISIBLE_DEVICES'] = '/gpu:0'

class_colors1 = [[0,0,0],[50,50,50]]
#class_colors1 = [[0,0,0],[0,255,0]]
class_colors2 = [[0,0,0],[0,0,0]]
NCLASSES = 2
HEIGHT = 416
WIDTH = 416


model = convnet_segnet(n_classes=NCLASSES,input_height=HEIGHT, input_width=WIDTH)
model.load_weights(r"C:/Users/ASUS/Desktop/segnet3/ep010-loss0.033-val_loss0.063.h5")

imgs = os.listdir(r"C:/Users/ASUS/Desktop/artificial/map/crop100_100")

for jpg in imgs:

    img = Image.open(r"C:/Users/ASUS/Desktop/artificial/map/crop100_100/"+jpg)
    old_img = copy.deepcopy(img)
    orininal_h = np.array(img).shape[0]
    orininal_w = np.array(img).shape[1]

    img = img.resize((WIDTH,HEIGHT))
    img = np.array(img)
    img = img/255
    img = img.reshape(-1,HEIGHT,WIDTH,3)
    pr = model.predict(img)[0]

    pr = pr.reshape((int(HEIGHT/2), int(WIDTH/2),NCLASSES)).argmax(axis=-1)

    seg_img = np.zeros((int(HEIGHT/2), int(WIDTH/2),3))
    seg_img2 = seg_img
    seg_img2 = seg_img2.copy()
    for i in range(0,seg_img.shape[0]):
        for j in range(0,seg_img.shape[1]):
            seg_img2[i,j]= 255 - seg_img[i,j]
    
    colors1 = class_colors1
    colors2 = class_colors2

    for c in range(NCLASSES):   
        seg_img2[:,:,0] += ((pr[:,: ] == c )*( colors1[c][0] )).astype('uint8')
        seg_img2[:,:,1] += ((pr[:,: ] == c )*( colors1[c][1] )).astype('uint8')
        seg_img2[:,:,2] += ((pr[:,: ] == c )*( colors1[c][2] )).astype('uint8')
        
        

    seg_img2 = Image.fromarray(np.uint8(seg_img2)).resize((orininal_w,orininal_h))
    
    image = Image.blend(old_img,seg_img2,0.4)

    image.save("C:/Users/ASUS/Desktop/artificial/img_out/"+jpg)




#import h5py
#
#f = h5py.File('Model.h5', 'r')
#print(f.attrs.get('keras_version'))