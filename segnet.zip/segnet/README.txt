所需环境
Keras==2.3.1
tensorflow==2.1.0

注意事项
1.注意根目录和相对目录的选取，以便正常训练
2.注意在predict.py中根据要求适当调整Image.blend()中的参数

训练步骤
1.准备好训练数据集，可以使用筏式养殖数据集进行测试；如果想进行自己的数据集测试，可以参考论文，在Labelme等中制作
2.准备好数据集后，加载对应的SegNet.txt
3.在上述步骤完成后，可以引入预训练文件（可省）
4.运行train.py进行训练

预测步骤
1.完成训练后，加载权重进行预测
2.将想要预测的图片放入一个文件夹中，加载进入模型
3.运行predict.py
4.预测结果放在入img_out文件夹

Reference
https://github.com/bubbliiiing/Semantic-Segmentation
