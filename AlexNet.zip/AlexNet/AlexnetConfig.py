#是否加载模型
load_model=False
#模型存储路径
model_path="save_model/alexnet.pth"
#学习率
learning_rate=1e-5
#迭代次数
EPOCH=2500
#batch_size
train_batchsize=1024
val_batchsize=256

