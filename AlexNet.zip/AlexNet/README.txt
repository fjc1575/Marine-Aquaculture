版本依赖
pytorch==1.8.1

注意事项
1.标签文件为npy格式，存放为0、1等数字，0表示为背景，1为目标。
2.list_result文件夹中存放训练过程中的epoch、loss、accuracy等信息，可根据需要进行画图。

训练步骤
1.将遥感图像按照16*16大小进行裁剪，人工分成训练集和验证集，分别存入datatset下面的oil_train和oil_val文件夹。
2.标签文件存成npy格式。
3.根据需要在train.py文件中调整路径，进行训练。

预测步骤
1.将想要预测的图片放入photo文件夹中，在predict.py文件中，修改为该图片名称即可。
2.运行predict/predict.py文件加载权重进行预测。
3.预测结果存放于predict/result文件夹中

Reference
https://github.com/WZMIAOMIAO/deep-learning-for-image-processing/blob/master/pytorch_classification/Test2_alexnet/model.py