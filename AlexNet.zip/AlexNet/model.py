import torch
from torch import nn
import math
from torch.nn import functional as F
from torch.autograd import Variable

#修改版
class AlexNet(nn.Module):
    def __init__(self,train=False):
        super().__init__()
        # 第一层是 5x5 的卷积，输入的channels 是 3，输出的channels是 64,步长 1,没有 padding
        # Conv2d 的第一个参数为输入通道，第二个参数为输出通道，第三个参数为卷积核大小
        # ReLU 的参数为inplace，True表示直接对输入进行修改，False表示创建新创建一个对象进行修改
        self.conv1 = nn.Sequential(
            nn.Conv2d(in_channels=3, out_channels=96,kernel_size=7,stride=3,padding=math.ceil((7-3)/2)),
            nn.ReLU(),
            nn.LocalResponseNorm(size=4, alpha=0.001/9.0, beta=0.75)
        )
        #self.max_pool1 = nn.MaxPool2d(kernel_size=3, stride=2)
        # 第三层是 5x5 的卷积， 输入的channels 是64，输出的channels 是64，没有padding
        self.conv2 = nn.Sequential(
            nn.Conv2d(in_channels=96,out_channels=256,kernel_size=5,stride=1,padding=math.ceil((5-1)/2)),
            nn.ReLU(),
            nn.LocalResponseNorm(size=4, alpha=0.001/9.0, beta=0.75)
        )
        self.max_pool2 = nn.MaxPool2d(kernel_size=3, stride=1)
        self.conv3 = nn.Sequential(
            nn.Conv2d(in_channels=256, out_channels=512, kernel_size=3, stride=1,padding=math.ceil((3-1)/2)),
            nn.ReLU()
        )

        self.conv4 = nn.Sequential(
            nn.Conv2d(in_channels=512, out_channels=512, kernel_size=3, stride=1,padding=math.ceil((3-1)/2)),
            nn.ReLU()
        )
        self.conv5 = nn.Sequential(
            nn.Conv2d(in_channels=512, out_channels=384, kernel_size=3, stride=1,padding=math.ceil((3-1)/2)),
            nn.ReLU()
        )
        # 第五层是全连接层，输入是 1204 ，输出是384
        self.fc1 = nn.Sequential(
            nn.Linear(3*3*384, 2048),
            nn.Dropout(p=0.6),
            nn.ReLU()
        )
        # 第六层是全连接层，输入是 384， 输出是192
        self.fc2 = nn.Sequential(
            nn.Linear(2048, 2048),
            nn.Dropout(p=0.6),
            nn.ReLU()
        )
        # 第七层是全连接层，输入是192， 输出是 10
        self.fc3 = nn.Linear(2048, 2)

    def forward(self, x):
        #第一层卷积+池化
        #print("输入:",x.shape)
        x=self.conv1(x)
        #print("conv1:",x.shape)
        #x=self.max_pool1(x)
        #print("max_pool1",x.shape)
        #第二层卷积
        x=self.conv2(x)
        #print("conv2:",x.shape)
        x = self.max_pool2(x)
        #p1 = self.p1(x)
        #p1=self.p_conv(p1)
        #print("max_pool2:",x.shape)
        #第三层卷积
        x=self.conv3(x)
        #p2 = self.p2(x)
        #p2 = self.p_conv(p2)
        #print("conv3:",x.shape)
        #第四层卷积
        x=self.conv4(x)
        #p3 = self.p3(x)
        #p3=self.p_conv(p3)
        #print("conv4:",x.shape)
        #第五层卷积
        x=self.conv5(x)
        #x=torch.cat((p1,p2,p3),dim=1)
        #print("conv5:",x.shape)
        #将矩阵拉伸成向量的形式，例：[batch,32,32,128]->[batch,32*32*128]
        x= x.view(x.shape[0], -1)
        #print("view:",x.shape)
        #第六层全连接层
        x=self.fc1(x)
        #print("fc1:",x.shape)
        #第七层全连接层
        x=self.fc2(x)
        #print("fc2:",x.shape)
        #第八层全连接层
        x=self.fc3(x)
        #print("fc3:",x.shape)
        #x=F.softmax(x,dim=1)
        return x

#刘佳旭原版
class AlexNet2(nn.Module):
    def __init__(self,train=False):
        super().__init__()
        # 第一层是 5x5 的卷积，输入的channels 是 3，输出的channels是 64,步长 1,没有 padding
        # Conv2d 的第一个参数为输入通道，第二个参数为输出通道，第三个参数为卷积核大小
        # ReLU 的参数为inplace，True表示直接对输入进行修改，False表示创建新创建一个对象进行修改
        self.conv1 = nn.Sequential(
            nn.Conv2d(in_channels=3, out_channels=96,kernel_size=11,stride=4,padding=math.ceil((11-4)/2)),
            nn.ReLU(),
            nn.LocalResponseNorm(size=4, alpha=0.001/9.0, beta=0.75)
        )
        # 第二层为 3x3 的池化，步长为2，没有padding
        self.max_pool1 = nn.MaxPool2d(kernel_size=3, stride=2)
        # 第三层是 5x5 的卷积， 输入的channels 是64，输出的channels 是64，没有padding
        self.conv2 = nn.Sequential(
            nn.Conv2d(in_channels=96,out_channels=256,kernel_size=5,stride=1,padding=math.ceil((5-1)/2)),
            nn.ReLU(),
            nn.LocalResponseNorm(size=4, alpha=0.001/9.0, beta=0.75)
        )
        #self.max_pool2 = nn.MaxPool2d(kernel_size=3, stride=2)
        self.conv3 = nn.Sequential(
            nn.Conv2d(in_channels=256, out_channels=384, kernel_size=3, stride=1, padding=math.ceil((3 - 1) / 2)),
            nn.ReLU()
        )
        self.conv4 = nn.Sequential(
            nn.Conv2d(in_channels=384, out_channels=384, kernel_size=3, stride=1, padding=math.ceil((3 - 1) / 2)),
            nn.ReLU()
        )
        self.conv5 = nn.Sequential(
            nn.Conv2d(in_channels=384, out_channels=256, kernel_size=3, stride=1, padding=math.ceil((3 - 1) / 2)),
            nn.ReLU()
        )

        # 第五层是全连接层，输入是 1204 ，输出是384
        self.fc1 = nn.Sequential(
            nn.Linear(1*1*256, 4096),
            nn.Dropout(p=0.6),
            nn.ReLU()
        )
        # 第六层是全连接层，输入是 384， 输出是192
        self.fc2 = nn.Sequential(
            nn.Linear(4096, 4096),
            nn.Dropout(p=0.6),
            nn.ReLU()
        )
        # 第七层是全连接层，输入是192， 输出是 10
        self.fc3 = nn.Linear(4096, 2)

    def forward(self, x):
        #第一层卷积+池化
        #print("输入:",x.shape)
        x=self.conv1(x)
        #print("conv1:",x.shape)
        x=self.max_pool1(x)
        #print("max_pool1",x.shape)
        #第二层卷积
        x=self.conv2(x)
        #print("conv2:",x.shape)
        #x = self.max_pool2(x)
        #print("max_pool2:",x.shape)
        #第三层卷积
        x=self.conv3(x)
        #print("conv3:",x.shape)
        #第四层卷积
        x=self.conv4(x)
        #print("conv4:",x.shape)
        #第五层卷积
        x=self.conv5(x)
        #print("conv5:",x.shape)
        #将矩阵拉伸成向量的形式，例：[batch,32,32,128]->[batch,32*32*128]
        x= x.view(x.shape[0], -1)
        #print("view:",x.shape)
        #第六层全连接层
        x=self.fc1(x)
        #print("fc1:",x.shape)
        #第七层全连接层
        x=self.fc2(x)
        #print("fc2:",x.shape)
        #第八层全连接层
        x=self.fc3(x)
        #print("fc3:",x.shape)
        #x=F.softmax(x,dim=1)
        return x
