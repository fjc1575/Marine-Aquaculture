import torch
import model
import numpy as np
import cv2
import os
from torch.utils.data import DataLoader, Dataset
import AlexnetConfig as config
import os
from tqdm import tqdm
from torch.nn import functional as F
import math
import time
from PIL import Image
os.environ['CUDA_VISIBLE_DEVICES'] = '0'
def opencvLoad(imgPath,resizeH,resizeW):
    image = cv2.imread(imgPath)
    image = cv2.resize(image, (resizeH, resizeW), interpolation=cv2.INTER_CUBIC)
    image = np.transpose(image, (2, 1, 0))
    image = torch.FloatTensor(image)/255
    return image
class LoadPartDataset(Dataset):
    def __init__(self, data_path,label):
        #初始化过程，(路径，类别)按照这种格式进行初始化
        imgs=[]
        data=os.listdir(data_path)
        for img in data:
            imgs.append((str(data_path+"/"+img),label[int(img.split(".")[0])]))
        self.imgs=imgs
    def __getitem__(self, item):
        image, label = self.imgs[item]
        img = opencvLoad(image,16,16)
        return img, label
    def __len__(self):
        return len(self.imgs)
if __name__=="__main__":
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    # 训练集路径
    train_path="dataset/oil_train/data"
    train_label=np.load("dataset/oil_train/oil_train.npy")
    # 验证集路径
    val_path="dataset/oil_val/data"
    val_label=np.load("dataset/oil_val/oil_val.npy")
    # 加载数据，数据预处理
    train_data=LoadPartDataset(train_path,train_label)
    val_data=LoadPartDataset(val_path,val_label)
    # 批处理数据,用来送入网络进行训练
    train_loader=DataLoader(dataset=train_data,batch_size=config.train_batchsize,shuffle=True,pin_memory=True)
    val_loader=DataLoader(dataset=val_data,batch_size=config.val_batchsize,shuffle=False,pin_memory=True)
    # 实例化模型
    model = model.AlexNet().to(device)
    print(model)
    # 使用Adam
    optimizer = torch.optim.Adam(model.parameters(), lr=config.learning_rate, weight_decay=0.0001)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.99)
    # 使用交叉熵作为损失函数
    loss_func = torch.nn.CrossEntropyLoss()
    #是否加载预训练权重
    config.load_model=False
    if config.load_model:
        checkpoint=torch.load(config.model_path)
        model.load_state_dict(checkpoint['net'],False)
        optimizer.load_state_dict(checkpoint['optimizer'])
        start_epoch=checkpoint['epoch']
        # 存放epoch
        epoch_list = np.load("result/result3/epoch_list.npy").tolist()
        # 存放loss
        loss_list = np.load("result/result3/loss_list.npy").tolist()
        # 存放在训练集上面的精确度
        train_accuracy_list = np.load("result/result3/train_accuracy_list.npy").tolist()
        # 存放在验证集上面的精确度
        val_accuracy_list = np.load("result/result3/val_accuracy_list.npy").tolist()
        val_loss_list=np.load("result/result3/val_loss_list.npy").tolist()
    else:
        start_epoch=-1
        # 存放epoch
        epoch_list = []
        # 存放loss
        loss_list = []
        # 存放在训练集上面的精确度
        train_accuracy_list = []
        # 存放在验证集上面的精确度
        val_accuracy_list = []
        val_loss_list=[]
    #开始训练
    for epoch in range(config.EPOCH):
        if epoch>start_epoch:
            train_loss=0
            val_all_loss=0
            temp_train_accuracy = 0
            temp_accuracy_number = 0
            # 使用进度条工具
            with tqdm(total=math.ceil(len(train_data) / config.train_batchsize),
                      desc=f'Epoch{epoch}/{config.EPOCH}', postfix=dict) as pbar:
                # 训练
                model.train()
                for sequence, (the_train_data, the_train_label) in enumerate(train_loader):
                    the_train_data_length=len(the_train_data)
                    optimizer.zero_grad(set_to_none=True)
                    # 预测
                    out_result = model(the_train_data.to(device))
                    # 计算损失
                    loss = loss_func(out_result, the_train_label.type(torch.long).to(device))
                    # 反向传播
                    loss.backward()
                    optimizer.step()
                    #计算精确度
                    out_result = F.softmax(out_result, dim=1)
                    # 计算预测准确的数量
                    train_accuracy_number = np.sum((np.argmax(out_result.cpu().detach().numpy(), axis=1) == the_train_label.cpu().detach().numpy()))
                    # 计算所有预测准确的数量
                    temp_accuracy_number += train_accuracy_number
                    # 本轮在训练集上面的精确度
                    train_accuracy = train_accuracy_number / the_train_label.shape[0]
                    train_loss=the_train_data_length*loss.item()+train_loss
                    # 进度条
                    pbar.set_postfix({'lr': optimizer.state_dict()['param_groups'][0]['lr'], 'loss': loss.item(),"train_accuracy": train_accuracy})
                    pbar.update()
                # 计算本次训练在训练集上面的精确度
                temp_train_accuracy = temp_accuracy_number / len(train_data)
                temp_val_accuracy = 0
                temp_val_accuracy_number = 0
                # 计算在验证集上面的准确度
                model.eval()
                with torch.no_grad():
                    for the_val_data, the_val_label in val_loader:
                        the_val_data = the_val_data.to(device)
                        # 获取标签
                        # 预测并将预测的结果转成numpy的形式
                        val_out_result=model(the_val_data)
                        val_loss = loss_func(val_out_result, the_val_label.type(torch.long).to(device))
                        val_result = F.softmax(val_out_result, dim=1).cpu().detach().numpy()
                        # 获取每一行最大的数的索引(5198,2)->(5198,),其中存放的的索引
                        val_result = np.argmax(val_result, axis=1)
                        # 将预测的结果和真实的进行比较,计算预测正确的数量,再与真实的进行计算,就获得了预测的准确性
                        result_num = (val_result == the_val_label.detach().numpy())
                        val_accuracy_number = np.sum(result_num == True)
                        temp_val_accuracy_number += val_accuracy_number
                        val_all_loss=val_loss.item()*len(the_val_data)+val_all_loss
                    # 保存epoch、loss、train_accuracy和val_accuracy
                    average_train_loss=train_loss/len(train_data)
                    average_val_loss=val_all_loss/len(val_data)
                    temp_val_accuracy = temp_val_accuracy_number / len(val_data)
                    epoch_list.append(epoch)
                    loss_list.append(average_train_loss)
                    val_loss_list.append(average_val_loss)
                    train_accuracy_list.append(temp_train_accuracy)
                    val_accuracy_list.append(temp_val_accuracy)
                    pbar.set_postfix({'lr': optimizer.state_dict()['param_groups'][0]['lr'], 'train_loss':average_train_loss ,
                                      "train_accuracy": temp_train_accuracy,"val_loss":average_val_loss,"val_accuracy": temp_val_accuracy})
                    pbar.update()
                # 如果在测试集上面的精确度是前面所有精确度之中最好的，则表明当前模型训练的比之前更好，则保存本次模型
                if temp_val_accuracy >= np.max(np.array(val_accuracy_list)):
                    save_name = "Epoch" + str(
                        epoch) + "-loss%.6f" % loss.item() + "-train_accuracy_%.6f" % temp_train_accuracy + "-val_loss%.6f" % val_loss.item() + "-val_accuracy%.6f" % temp_val_accuracy + ".pth"
                    save_path = "save_model/" + save_name
                    state={'net':model.state_dict(),"epoch":epoch,"optimizer":optimizer.state_dict()}
                    torch.save(state, save_path)
                # 每100轮保存一次
                if epoch % 100 == 0:
                    save_name = "Epoch" + str(
                        epoch) + "-loss%.6f" % loss.item() + "-train_accuracy_%.6f" % temp_train_accuracy + "-val_loss%.6f" % val_loss.item() + "-val_accuracy%.6f" % temp_val_accuracy + ".pth"
                    save_path = "save_model/" + save_name
                    state={'net':model.state_dict(),"epoch":epoch,"optimizer":optimizer.state_dict()}
                    torch.save(state, save_path)
                    np.save("list_result/epoch_list.npy", np.array(epoch_list))
                    np.save("list_result/train_loss_list.npy", np.array(loss_list))
                    np.save("list_result/train_accuracy_list.npy", np.array(train_accuracy_list))
                    np.save("list_result/val_accuracy_list.npy", np.array(val_accuracy_list))
                    np.save("list_result/val_loss_list.npy",np.array(val_loss_list))
                # 保留最后一次的结果
                if epoch == config.EPOCH - 1:
                    save_name = "Epoch" + str(
                        epoch) + "-loss%.6f" % loss.item() + "-train_accuracy_%.6f" % temp_train_accuracy + "-val_loss%.6f" % val_loss.item() + "-val_accuracy%.6f" % temp_val_accuracy + ".pth"
                    save_path = "save_model/" + save_name
                    state={'net':model.state_dict(),"epoch":epoch,"optimizer":optimizer.state_dict()}
                    torch.save(state, save_path)
                    np.save("list_result/epoch_list.npy", np.array(epoch_list))
                    np.save("list_result/train_loss_list.npy", np.array(loss_list))
                    np.save("list_result/train_accuracy_list.npy", np.array(train_accuracy_list))
                    np.save("list_result/val_accuracy_list.npy", np.array(val_accuracy_list))
                    np.save("list_result/val_loss_list.npy", np.array(val_loss_list))
            # 更新梯度
            scheduler.step()















