from torch.nn import functional as F
from PIL import Image
import numpy as np
import torch
import model
import time
import math
import cv2

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
def pretement(image):
    #如果需要预处理，则增加在该处
    return image
def imagesplit(image):
    torch.tensor(image).to(device)
    height,width,channel=image.shape
    size = 16
    stride = 7
    row_num=math.ceil((height-size)/stride)+1
    col_num=math.ceil((width-size)/stride)+1
    image1=torch.randn((1,channel,size,size)).to(device)
    save_num=0
    for x in range(row_num):
        for y in range(col_num):
            if x == row_num - 1 and y == col_num - 1:
                img = image[height - size:height,width - size:width,:]
            elif y == col_num - 1:
                img = image[stride*x:size+stride*x,width-size:width,:]
            elif x == row_num - 1:
                img = image[height-size:height,stride*y:size+stride*y,:]
            else:
                img = image[stride*x:size+stride*x,stride*y:size+stride*y,:]
            save_num = save_num + 1
            img=np.array(Image.fromarray(img).resize((16,16)))
            img = np.transpose(img, (2, 1, 0))
            img = np.array([img])
            img = torch.from_numpy(img).to(device)
            if x == 0 and y == 0:
                image1 = img
            else:

                image1 = torch.cat([image1, img], dim=0).to(device)
    image1=image1.cpu()
    np.save("split_result.npy",image1)
    return image1.numpy()
def imagepredict(image,save_model):
    #实例化模型
    net = model.AlexNet().to(device)
    checkpoint = torch.load(save_model)
    net.load_state_dict(checkpoint['net'])
    image=(torch.FloatTensor(image)/255)
    batch=math.ceil(image.shape[0]/128)
    final_result=np.array([],dtype='int8')
    net.eval()
    for i in range(batch):
        now_image = image[i * 128:128 + i * 128, :, :, :]
        now_image=now_image.to(device)
        result = net(now_image)
        result = F.softmax(result, dim=1).cpu().detach().numpy()
        result = np.argmax(result, axis=1)
        final_result=np.concatenate((final_result,result),axis=0)
    np.save("predict_result.npy",final_result)
    return final_result
def splicingimage(image,label):
    height,width,channel=image.shape
    size = 16
    stride = 7
    row_num=math.ceil((height-size)/stride)+1
    col_num=math.ceil((width-size)/stride)+1
    splicing_image_numpy=np.zeros((height,width),dtype='int8')
    start_num=0
    for x in range(row_num):
        for y in range(col_num):
            if label[start_num] == 1:
                if x == row_num - 1 and y == col_num - 1:
                    splicing_image_numpy[height - size:height,width - size:width]=255
                elif y == col_num - 1:
                    splicing_image_numpy[stride*x:size+stride*x,width-size:width]=255
                elif x == row_num - 1:
                    splicing_image_numpy[height-size:height,stride*y:size+stride*y]=255
                else:
                    splicing_image_numpy[stride*x:size+stride*x,stride*y:size+stride*y] = 255
            start_num=start_num+1
    return splicing_image_numpy
def getaccuracy(imagepath,labelpath,name):
    image=np.load(imagepath)
    Image.fromarray(image).convert("RGB").save("getaccuracy.jpg",quality=95)
    image=cv2.imread("getaccuracy.jpg",0)
    label=Image.open(labelpath)
    label=np.array(label)

    image = cv2.imread("getaccuracy.jpg", 0)
    # 腐蚀膨胀
    kernel1 = np.ones((17, 17), np.uint8)
    kernel2 = np.ones((16, 16), np.uint8)
    # 开运算
    image=cv2.erode(image,kernel1)
    image=cv2.dilate(image,kernel2)
    # 闭运算
    image = cv2.dilate(image, kernel2)
    image = cv2.erode(image, kernel1)
    Image.fromarray(image).save("result/result.png", quality=95)
    image_result=image
    # 计算精度
    tp=0
    tn=0
    fp=0
    fn=0
    for i in range(image.shape[0]):
        for j in range(image.shape[1]):
            if image[i,j]==255 and label[i,j]==1:
                tp=tp+1
            elif image[i,j]==0 and label[i,j]==0:
                tn=tn+1
            elif image[i,j]==255 and label[i,j]==0:
                fp=fp+1
            elif image[i,j]==0 and label[i,j]==1:
                fn=fn+1

    accuracy=(tp+tn)/(tp+tn+fp+fn)
    pe=((tn+fn)*(tn+fp)+(fp+tp)*(fn+tp))/((tp+tn+fp+fn)*(tp+tn+fp+fn))
    kp=(accuracy-pe)/(1-pe)
    np.save("result.npy",np.array([tp,tn,fp,fn]))
    print("accuracy:",accuracy,"kappa",kp)
    return image_result
def splicing(image,imagename):
    H,W=image.shape
    origin_image=Image.open("photo/"+str(imagename)+".jpg").convert("RGB")
    origin_image=np.array(origin_image)
    for i in range(H):
        for j in range(W):
            if image[i,j]==255:
                origin_image[i,j,:]=[255,0,0]
    Image.fromarray(origin_image).save("result/result.jpg",quality=95)
def main(a):
    # 图片和标签的路径
    imgPath = "photo/"+str(a)+".jpg"
    labelPath = "photo/"+str(a)+".png"
    save_model="../save_model/alexnet.pth"
    # 读取图片并转成numpy格式
    image = cv2.imread(imgPath)
    image = np.array(image)

    # 图片预处理
    start_time = time.time()
    if True:
        image = pretement(image)
    print("预处理总计", time.time() - start_time, "s")

    # 裁剪图片
    start_time = time.time()
    if True:
        split_image = imagesplit(image)
    else:
        split_image = np.load("split_result.npy")
    print("分割图片总计", time.time() - start_time, "s")

    # 预测图片
    start_time = time.time()
    if True:
        predict_label = imagepredict(split_image,save_model)
    else:
        predict_label = np.load("predict_result.npy")
    print("预测图片总计", time.time() - start_time, "s")

    # 拼接图片
    start_time = time.time()
    out = splicingimage(image,predict_label)
    np.save("splicing_image.npy", out)
    print("拼接图片总计", time.time() - start_time, "s")

    #腐蚀膨胀获取二值图，并使用混淆矩阵对结果进行评价
    image = getaccuracy("splicing_image.npy", labelPath,a)
    #映射回原图
    splicing(image, a)

if __name__=="__main__":
    main(0)




