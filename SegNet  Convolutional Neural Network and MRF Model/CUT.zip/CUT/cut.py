# -*- coding: utf-8 -*-
"""
Created on Thu Mar 19 18:31:47 2020

@author: Administrator
"""

import cv2
import os
import numpy as np
##裁剪部分
cols=100
rows=100
step=100

filename='11img.png'
img = cv2.imread(r"C:/Users/ASUS/Desktop/"+filename,4)
sum_rows,sum_cols=img.shape[:2] 

if (sum_rows-rows)%step == 0:
    line = int((sum_rows-rows)/step+1)
    num = 0   
else:
    for x in range(sum_rows):
        if ((x-1)*step+rows)-sum_rows < rows-step:
            line = x
            num = ((line-1)*step+rows)-sum_rows
    
img = cv2.copyMakeBorder(img, 0, num, 0, num, cv2.BORDER_CONSTANT, value=(0, 0, 0))
new_rows,new_cols=img.shape[:2]
  
save_path="C:/Users/ASUS/Desktop/artificial/map/"+"crop{0}_{1}/".format(cols,rows)  #保存的路径
if not os.path.exists(save_path):
    os.makedirs(save_path)
    
print("裁剪所得{0}列图片，{1}行图片.".format(int(line),int(line))) 
    
for i in range(int(line)):
     for j in range(int(line)):
         cv2.imwrite(save_path+os.path.splitext(filename)[0]+'_'+str(j)+'_'+str(i)+os.path.splitext(filename)[1],img[j*step:j*step+rows,i*step:i*step+cols,:])
            
print("裁剪完成，得到{0}张图片.".format(int(line)*int(line)))
print("文件保存在{0}".format(save_path))

##合并部分
num_of_cols=10
num_of_rows=10
merge_path=r'C:/Users/ASUS/Desktop/artificial/'

dst=np.zeros((step*(num_of_rows-1)+rows,step*(num_of_cols-1)+rows,3),np.uint8) 

for filename in os.listdir(r'C:/Users/ASUS/Desktop/artificial/img_out2/'):
    map=cv2.imread(r'C:/Users/ASUS/Desktop/artificial/img_out2/'+filename)   
    cols,rows,channels=map.shape[:3]
    cols_th=int(filename.split("_")[-1].split('.')[0])
    rows_th=int(filename.split("_")[-2])
    roi=map[0:rows,0:cols,:]
    dst[rows_th*step:rows_th*step+rows,cols_th*step:cols_th*step+cols,:]=roi
    cv2.imwrite(merge_path+"merge1.png",dst)
   

    





