所需环境
opencv==3.4.2
numpy==1.19.2

注意事项
1.代码分为裁剪部分和合并部分；运行其中一部分时，注意注释掉另一部分
2.cols、rows、step分别自定义裁剪所得小图像的长、宽、步长
3.line为裁剪所得的行、列
4.合并部分的num_of_cols和num_of_rows对应裁剪部分的line

Reference
https://github.com/guoya1003/data_process/blob/master/clip_merge_picture.py