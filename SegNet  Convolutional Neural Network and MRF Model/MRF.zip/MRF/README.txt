所需环境
opencv==3.4.2
matplotlib==3.3.2

注意事项
1.注意根目录和相对目录的选取，以便正常读取
2.注意调整最大迭代次数max_iter

Reference
https://blog.csdn.net/weixin_42150745/article/details/112700037
